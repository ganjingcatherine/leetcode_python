# Binary Indexed Trees


相关题目： [s307. Range Sum Query - Mutable](https://leetcode.com/problems/range-sum-query-mutable/)

参考： 
[夜深人静写算法（三） - 树状数组](http://www.cppblog.com/menjitianya/archive/2015/11/02/212171.html)


